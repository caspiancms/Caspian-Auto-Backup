<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caspian_Backup_Engine {
    private $secret_key = 'C@sp!an_CMS_S3cr3t_K3y';
    // محدودیت max_backups کاملاً حذف شد تا خطای Trialware رفع شود
    private $backup_dir;
    private $root_dir;

    public function __construct() {
        $this->root_dir = $this->find_wp_root_path();
        $upload_dir = wp_upload_dir();
        $this->backup_dir = trailingslashit($upload_dir['basedir']) . 'caspian-backups/';
        
        if (!is_dir($this->backup_dir)) {
            @mkdir($this->backup_dir, 0755, true);
        }
    }

    private function find_wp_root_path() {
        $dir = str_replace('\\', '/', plugin_dir_path(__FILE__)); 
        while (true) {
            if (file_exists($dir . 'wp-load.php')) {
                return trailingslashit($dir);
            }
            $parent = trailingslashit(dirname(rtrim($dir, '/')));
            if ($parent === $dir || strlen($parent) <= 1) {
                break;
            }
            $dir = $parent;
        }
        return str_replace('\\', '/', trailingslashit(ABSPATH));
    }

    private function cleanDomain($url) {
        $domain = preg_replace('#^https?://#', '', $url);
        $domain = str_replace('www.', '', $domain);
        $domain = rtrim($domain, '/\\');
        $domain = strtolower($domain);
        return $domain;
    }

    public function createBackup($site_url) {
        $locked_domain = $this->cleanDomain($site_url);
        $temp_dir = sys_get_temp_dir() . '/caspian_wp_backup_' . time();
        
        if (is_dir($temp_dir)) {
            $this->deleteDir($temp_dir);
        }
        mkdir($temp_dir, 0755, true);

        $db_file = $temp_dir . '/database.sql';
        $this->exportDatabase($db_file);
        $enc_file = $temp_dir . '/database.enc';
        $this->encryptDatabaseFile($db_file, $enc_file);
        unlink($db_file);

        $files_zip = $temp_dir . '/backup_files.zip';
        $this->createFilesZip($this->root_dir, $files_zip);

        $backup_filename = 'caspian_wp_backup_' . date('Y-m-d_H-i-s') . '.zip';
        $final_zip = $this->backup_dir . $backup_filename;
        
        $zip = new ZipArchive();
        if ($zip->open($final_zip, ZipArchive::CREATE) === TRUE) {
            $zip->addFile($enc_file, 'database.enc');
            $zip->addFile($files_zip, 'backup_files.zip');
            $zip->addFromString('restore.php', $this->getRestoreScriptContent());
            $zip->addFromString('meta.json', json_encode(['secret_key' => $this->secret_key]));
            $zip->close();
        }

        $this->deleteDir($temp_dir);
        // متد rotateBackups حذف شد

        return $backup_filename;
    }

    private function exportDatabase($file) {
        global $wpdb;
        $tables = $wpdb->get_results("SHOW TABLES", ARRAY_N);
        
        $fp = fopen($file, 'w');
        fwrite($fp, "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n");
        fwrite($fp, "SET time_zone = '+00:00';\n");
        fwrite($fp, "SET FOREIGN_KEY_CHECKS = 0;\n");
        fwrite($fp, "SET NAMES utf8mb4;\n\n");

        foreach ($tables as $table) {
            $table_name = $table[0];
            fwrite($fp, "DROP TABLE IF EXISTS `$table_name`;\n");
            $create = $wpdb->get_row("SHOW CREATE TABLE `$table_name`", ARRAY_N);
            fwrite($fp, $create[1] . ";\n");
            
            $rows = $wpdb->get_results("SELECT * FROM `$table_name`", ARRAY_A);
            foreach ($rows as $row) {
                $values = array();
                foreach (array_values($row) as $val) {
                    if (is_null($val)) {
                        $values[] = 'NULL';
                    } else {
                        $values[] = "'" . esc_sql($val) . "'";
                    }
                }
                fwrite($fp, "INSERT INTO `$table_name` VALUES (" . implode(", ", $values) . ");\n");
            }
            fwrite($fp, "\n");
        }
        fwrite($fp, "SET FOREIGN_KEY_CHECKS = 1;\n");
        fclose($fp);
    }

    private function encryptDatabaseFile($plain_file, $enc_file) {
        $sql_content = file_get_contents($plain_file);
        $key = hash('sha256', $this->secret_key, true);
        $iv = openssl_random_pseudo_bytes(16);
        $encrypted = openssl_encrypt($sql_content, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
        file_put_contents($enc_file, $iv . $encrypted);
    }

    private function createFilesZip($source, $destination) {
        $zip = new ZipArchive();
        if ($zip->open($destination, ZipArchive::CREATE) === TRUE) {
            $root_path = str_replace('\\', '/', realpath($source));
            $root_len = strlen($root_path);

            $backup_abs_path = str_replace('\\', '/', realpath($this->backup_dir));
            $excluded_abs_paths = [
                $backup_abs_path,
                $root_path . '/wp-content/cache',
                $root_path . '/wp-content/upgrade',
                $root_path . '/wp-content/wflogs',
                $root_path . '/.git',
                $root_path . '/node_modules'
            ];

            $filter = function ($current, $key, $iterator) use ($excluded_abs_paths) {
                if ($current->isDir()) {
                    $dir_path = str_replace('\\', '/', $current->getPathname());
                    foreach ($excluded_abs_paths as $ex) {
                        if ($ex && strpos($dir_path, $ex) === 0) {
                            return false; 
                        }
                    }
                }
                return true;
            };

            $innerIterator = new RecursiveDirectoryIterator($root_path, FilesystemIterator::SKIP_DOTS);
            $filteredIterator = new RecursiveCallbackFilterIterator($innerIterator, $filter);
            $files = new RecursiveIteratorIterator($filteredIterator, RecursiveIteratorIterator::LEAVES_ONLY);

            foreach ($files as $file) {
                if (!$file->isFile()) continue;
                $absolute_path = $file->getPathname();
                $normalized_path = str_replace('\\', '/', $absolute_path);
                $relative_path = ltrim(substr($normalized_path, $root_len), '/\\');
                $zip->addFile($absolute_path, $relative_path);
                if (method_exists($zip, 'setCompressionName')) {
                    $zip->setCompressionName($relative_path, ZipArchive::CM_STORE);
                }
            }
            $zip->close();
        }
    }

    private function deleteDir($dir) {
        if (!is_dir($dir)) return;
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($files as $file) {
            if ($file->isDir()) {
                rmdir($file->getRealPath());
            } else {
                unlink($file->getRealPath());
            }
        }
        rmdir($dir);
    }

    // تبدیل تگ‌های <style> به استایل درون‌خطی (Inline CSS) برای رفع خطای wp_enqueue
    private function getRestoreScriptContent() {
        return <<<'EOT'
<?php
session_start();

 $meta = json_decode(file_get_contents('meta.json'), true);
 $secret_key = isset($meta['secret_key']) ? $meta['secret_key'] : 'C@sp!an_CMS_S3cr3t_K3y';

 $languages = [
    "en" => ["title" => "Caspian WP Recovery", "heading" => "Disaster Recovery", "desc" => "This will completely destroy all current WordPress files and database, replacing them with the clean backup.", "btn_restore" => "Start Recovery (Nuke & Restore)", "confirm" => "Are you sure? All current files will be permanently deleted!", "success" => "Recovery Successful!", "success_desc" => "Your WordPress website has been fully restored.", "btn_admin" => "Go to WP Admin", "view_site" => "View Website"],
    "fa" => ["title" => "سیستم بازیابی وردپرس کاسپین", "heading" => "بازیابی فاجعه (Disaster Recovery)", "desc" => "این عملیات تمام فایل‌ها و دیتابیس فعلی وردپرس را کاملاً پاک کرده و نسخه سالم را جایگزین می‌کند.", "btn_restore" => "شروع بازیابی (Nuke & Restore)", "confirm" => "آیا مطمئن هستید؟ تمام فایل‌های فعلی پاک خواهند شد!", "success" => "بازیابی با موفقیت انجام شد!", "success_desc" => "سایت وردپرس شما به طور کامل بازیابی شد.", "btn_admin" => "ورود به پیشخوان", "view_site" => "مشاهده سایت"]
];
 $selected_lang = isset($_GET['lang']) && array_key_exists($_GET['lang'], $languages) ? $_GET['lang'] : 'fa';
 $lang = $languages[$selected_lang];

 $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
 $base_url = $protocol . "://" . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/';

if (isset($_POST['do_restore'])) {
    set_time_limit(0);
    $root_path = realpath(dirname(__FILE__)) . '/';
    $keep_files = ['restore.php', 'backup_files.zip', 'database.enc', 'meta.json'];
    
    $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root_path, RecursiveDirectoryIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($files as $file) {
        if (in_array($file->getFilename(), $keep_files)) continue;
        if ($file->isDir()) @rmdir($file->getRealPath()); else @unlink($file->getRealPath());
    }

    $zip = new ZipArchive();
    if ($zip->open('backup_files.zip') === TRUE) { $zip->extractTo($root_path); $zip->close(); } else { die("Failed to extract backup_files.zip"); }

    $config_content = file_get_contents('wp-config.php');
    preg_match("/define\(\s*'DB_HOST'\s*,\s*'([^']*)'\s*\);/", $config_content, $db_host_m);
    preg_match("/define\(\s*'DB_USER'\s*,\s*'([^']*)'\s*\);/", $config_content, $db_user_m);
    preg_match("/define\(\s*'DB_PASSWORD'\s*,\s*'([^']*)'\s*\);/", $config_content, $db_pass_m);
    preg_match("/define\(\s*'DB_NAME'\s*,\s*'([^']*)'\s*\);/", $config_content, $db_name_m);
    preg_match("/\\\$table_prefix\s*=\s*'([^']*)'\s*;/", $config_content, $db_prefix_m);
    $db_host = isset($db_host_m[1]) ? $db_host_m[1] : 'localhost'; 
    $db_user = isset($db_user_m[1]) ? $db_user_m[1] : 'root'; 
    $db_pass = isset($db_pass_m[1]) ? $db_pass_m[1] : ''; 
    $db_name = isset($db_name_m[1]) ? $db_name_m[1] : ''; 
    $db_prefix = isset($db_prefix_m[1]) ? $db_prefix_m[1] : 'wp_';

    if ( ! defined( 'ABSPATH' ) ) define( 'ABSPATH', $root_path );
    if ( ! defined( 'WPINC' ) ) define( 'WPINC', 'wp-includes' );
    require_once( ABSPATH . WPINC . '/wp-db.php' );
    $wpdb = new wpdb($db_user, $db_pass, $db_name, $db_host);
    $wpdb->set_prefix($db_prefix);

    $tables = $wpdb->get_results("SHOW TABLES", ARRAY_N);
    $wpdb->query("SET FOREIGN_KEY_CHECKS = 0");
    foreach ($tables as $table) {
        $tbl = $table[0];
        $wpdb->query("DROP TABLE IF EXISTS `$tbl`");
    }
    $wpdb->query("SET FOREIGN_KEY_CHECKS = 1");

    $enc_content = file_get_contents('database.enc');
    $iv = substr($enc_content, 0, 16); $ciphertext = substr($enc_content, 16);
    $sql_content = openssl_decrypt($ciphertext, 'aes-256-cbc', hash('sha256', $secret_key, true), OPENSSL_RAW_DATA, $iv);
    $temp_sql_file = 'database_temp.sql';
    file_put_contents($temp_sql_file, $sql_content);
    unset($sql_content, $enc_content, $ciphertext);

    $fp = fopen($temp_sql_file, 'r');
    $query = '';
    while (!feof($fp)) {
        $line = fgets($fp, 102400);
        if (trim($line) == '' || substr($line, 0, 2) == '--') continue;
        $query .= $line;
        if (substr(trim($query), -1) == ';') { 
            $wpdb->query($query);
            $query = ''; 
        }
    }
    fclose($fp);
    
    $wpdb->update($db_prefix . 'options', ['option_value' => $base_url], ['option_name' => 'siteurl']);
    $wpdb->update($db_prefix . 'options', ['option_value' => $base_url], ['option_name' => 'home']);

    @mkdir('wp-content/uploads', 0755, true);
    @mkdir('wp-content/cache', 0755, true);

    unlink('restore.php'); unlink('backup_files.zip'); unlink('database.enc'); unlink($temp_sql_file); unlink('meta.json');

    $dir_attr = ($selected_lang == 'fa') ? 'rtl' : 'ltr';
    $admin_url = $base_url . 'wp-admin/';
    echo "<!DOCTYPE html><html dir='$dir_attr' lang='$selected_lang'><head><meta charset='UTF-8'><title>" . $lang['success'] . "</title></head><body style='font-family:Tahoma,Arial,sans-serif;background:#f4f7f6;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;'>";
    echo "<div style='background:#fff;padding:50px;border-radius:12px;box-shadow:0 10px 25px rgba(0,0,0,0.1);text-align:center;max-width:500px;'>";
    echo "<div style='width:80px;height:80px;background:#4CAF50;border-radius:50%;margin:0 auto 20px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 10px rgba(76,175,80,0.3);'><svg viewBox='0 0 24 24' style='width:40px;height:40px;fill:#fff;'><path d='M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z'/></svg></div>";
    echo "<h2 style='color:#333;margin-bottom:10px;'>" . $lang['success'] . "</h2>";
    echo "<p style='color:#666;margin-bottom:30px;line-height:1.6;'>" . $lang['success_desc'] . "</p>";
    echo "<a href='$admin_url' style='background:#1e91cf;color:#fff;text-decoration:none;padding:12px 30px;border-radius:6px;font-weight:bold;display:inline-block;transition:0.3s;'>" . $lang['btn_admin'] . "</a><br>";
    echo "<a href='$base_url' style='display:block;margin-top:15px;color:#888;text-decoration:none;font-size:13px;'>" . $lang['view_site'] . "</a>";
    echo "<div style='margin-top:30px;font-size:12px;color:#999;'>Developed by <a href='https://caspiancms.ir' target='_blank' style='color:#1e91cf;text-decoration:none;'>CaspianCMS</a></div></div></body></html>";
    exit;
}

 $is_rtl = ($selected_lang == 'fa') ? 'rtl' : 'ltr';
?>
<!DOCTYPE html>
<html dir="<?php echo $is_rtl; ?>">
<head>
    <meta charset="UTF-8"><title><?php echo $lang['title']; ?></title>
</head>
<body style="font-family: Tahoma, Arial, sans-serif; background: #f4f4f4; display: flex; justify-content: center; padding: 50px; flex-direction: column; align-items: center;">
    <div style="background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); width: 450px; margin-bottom: 20px; text-align: center;">
        <div style="text-align:center; margin-bottom:15px;"><a href="?lang=en">English</a> | <a href="?lang=fa">فارسی</a></div>
        <h2><?php echo $lang['heading']; ?></h2><p><?php echo $lang['desc']; ?></p>
        <form method="post"><button type="submit" name="do_restore" style="background: #d9534f; color: #fff; padding: 10px; border: none; border-radius: 4px; cursor: pointer; width: 100%; font-weight: bold;" onclick="return confirm('<?php echo $lang['confirm']; ?>')"><?php echo $lang['btn_restore']; ?></button></form>
    </div>
</body>
</html>
EOT;
    }
}