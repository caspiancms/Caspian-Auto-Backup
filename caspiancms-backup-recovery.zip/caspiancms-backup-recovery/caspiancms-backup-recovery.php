<?php
/**
 * Plugin Name: CaspianCMS Backup & Recovery
 * Plugin URI: https://caspiancms.ir
 * Description: Instantly recover your hacked WordPress site. Nuke & Pave restoration destroys infected files and rebuilds a clean site in seconds.
 * Version: 1.3
 * Author: CaspianCMS
 * Requires at least: 5.0
 * Tested up to: 7.1
 * Requires PHP: 7.2
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: caspiancms-backup-recovery
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'includes/class-caspian-backup-engine.php';

function caspian_t($key) {
    $fa = array(
        'page_title'      => 'سیستم بک‌آپ و بازیابی کاسپین',
        'cron_title'      => 'اتوماسیون بک‌آپ‌گیری (Cron Job)',
        'cron_desc'       => 'برای بک‌آپ‌گیری خودکار، آدرس زیر را در بخش Cron Job هاست خود (مثلاً روزی یک‌بار) قرار دهید:',
        'manual_title'    => 'ساخت بک‌آپ دستی',
        'manual_desc'     => 'با کلیک روی دکمه زیر، یک پکیج بازیابی کامل از سایت شما ساخته می‌شود.',
        'btn_manual'      => 'ساخت بک‌آپ دستی',
        'list_title'      => 'لیست پکیج‌های بازیابی',
        'col_filename'    => 'نام فایل',
        'col_size'        => 'حجم',
        'col_date'        => 'تاریخ ساخت',
        'col_action'      => 'عملیات',
        'no_backups'      => 'هیچ بک‌آپی وجود ندارد.',
        'btn_download'    => 'دانلود',
        'btn_delete'      => 'حذف',
        'success_msg'     => 'پکیج بازیابی با موفقیت ساخته شد!',
        'developer'       => 'توسعه یافته توسط <a href="https://caspiancms.ir" target="_blank" style="color: #1e91cf; font-weight: bold;">کاسپین مارکت | CaspianCMS</a>'
    );

    $en = array(
        'page_title'      => 'Caspian Backup & Recovery System',
        'cron_title'      => 'Backup Automation (Cron Job)',
        'cron_desc'       => 'To set up automatic backups, enter the following URL in your host\'s Cron Job section (e.g., once a day):',
        'manual_title'    => 'Create Manual Backup',
        'manual_desc'     => 'By clicking the button below, a full recovery package of your site will be created.',
        'btn_manual'      => 'Create Backup',
        'list_title'      => 'Recovery Packages List',
        'col_filename'    => 'File Name',
        'col_size'        => 'Size',
        'col_date'        => 'Date Created',
        'col_action'      => 'Action',
        'no_backups'      => 'No backups available.',
        'btn_download'    => 'Download',
        'btn_delete'      => 'Delete',
        'success_msg'     => 'Backup created successfully!',
        'developer'       => 'Developed by <a href="https://caspiancms.ir" target="_blank" style="color: #1e91cf; font-weight: bold;">CaspianCMS</a>'
    );

    $locale = get_locale();
    $lang = (strpos($locale, 'fa') !== false) ? $fa : $en;
    return isset($lang[$key]) ? $lang[$key] : $key;
}

add_action('admin_enqueue_scripts', 'caspian_enqueue_assets');
function caspian_enqueue_assets($hook) {
    if (strpos($hook, 'caspian-backup') === false) return;
    
    wp_register_script('caspian-admin', '', array('jquery'), '1.3', true);
    wp_enqueue_script('caspian-admin');
    
    $data = array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('caspian_admin_nonce')
    );
    wp_add_inline_script('caspian-admin', 'var caspianData = ' . wp_json_encode($data) . ';');
    
    $custom_js = "jQuery(document).ready(function($){
        $('.caspian-del-btn').on('click', function(e){ 
            e.preventDefault(); 
            if(!confirm('Are you sure?')) return; 
            var btn=$(this); 
            var filename=btn.data('filename'); 
            $.post(caspianData.ajax_url, {
                action:'caspian_delete_backup', 
                nonce: caspianData.nonce, 
                filename: filename
            }, function(res){ 
                if(res.success){ btn.closest('tr').fadeOut(400, function(){ $(this).remove(); }); } 
                else { alert(res.data.message); } 
            }); 
        });
    });";
    wp_add_inline_script('caspian-admin', $custom_js);
}

add_action('admin_init', 'caspian_handle_file_actions');
function caspian_handle_file_actions() {
    if (isset($_GET['page']) && $_GET['page'] === 'caspian-backup' && isset($_GET['caspian_download'])) {
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'caspian_download_' . sanitize_file_name($_GET['caspian_download']))) {
            wp_die('Security failed.');
        }
        $filename = sanitize_file_name($_GET['caspian_download']);
        $upload_dir = wp_upload_dir();
        $file = trailingslashit($upload_dir['basedir']) . 'caspian-backups/' . $filename;
        
        if (file_exists($file)) {
            while (ob_get_level() > 0) { ob_end_clean(); }
            nocache_headers();
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Length: ' . filesize($file));
            readfile($file);
            exit;
        }
        wp_die('File not found.');
    }
}

add_action('wp_ajax_caspian_delete_backup', 'caspian_delete_backup_ajax');
function caspian_delete_backup_ajax() {
    check_ajax_referer('caspian_admin_nonce', 'nonce');
    $filename = sanitize_file_name($_POST['filename']);
    $upload_dir = wp_upload_dir();
    $file = trailingslashit($upload_dir['basedir']) . 'caspian-backups/' . $filename;
    if (file_exists($file)) {
        @unlink($file);
        wp_send_json_success(['message' => 'Deleted']);
    }
    wp_send_json_error(['message' => 'File not found']);
}

add_action('admin_menu', 'caspian_backup_menu');
function caspian_backup_menu() {
    add_menu_page(caspian_t('page_title'), 'Caspian Backup', 'manage_options', 'caspian-backup', 'caspian_backup_page_html', 'dashicons-shield-alt', 80);
}

function caspian_backup_page_html() {
    if (!current_user_can('manage_options')) return;

    if (isset($_POST['caspian_create_backup']) && check_admin_referer('caspian_create_backup_action', 'caspian_create_backup_nonce')) {
        @set_time_limit(0);
        $engine = new Caspian_Backup_Engine();
        $engine->createBackup(home_url());
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html(caspian_t('success_msg')) . '</p></div>';
    }

    $cron_token = md5(AUTH_KEY . 'caspian_cron_salt');
    $cron_url = site_url() . '/wp-content/plugins/caspiancms-backup-recovery/caspian-cron.php?token=' . $cron_token;

    $upload_dir = wp_upload_dir();
    $backup_dir = trailingslashit($upload_dir['basedir']) . 'caspian-backups/';
    $backups = is_dir($backup_dir) ? glob($backup_dir . 'caspian_wp_backup_*.zip') : [];
    rsort($backups);
    ?>
    <div class="wrap">
        <h1><span class="dashicons dashicons-shield-alt"></span> <?php echo esc_html(caspian_t('page_title')); ?></h1>
        
        <div class="card" style="max-width: 100%; padding: 15px; margin-bottom: 20px;">
            <h2 class="title"><span class="dashicons dashicons-clock"></span> <?php echo esc_html(caspian_t('cron_title')); ?></h2>
            <p><?php echo esc_html(caspian_t('cron_desc')); ?></p>
            <input type="text" class="regular-text" value="<?php echo esc_attr($cron_url); ?>" readonly onclick="this.select();" style="direction:ltr; text-align:left;">
        </div>

        <div class="card" style="max-width: 100%; padding: 15px; margin-bottom: 20px;">
            <h2 class="title"><span class="dashicons dashicons-database-add"></span> <?php echo esc_html(caspian_t('manual_title')); ?></h2>
            <p><?php echo esc_html(caspian_t('manual_desc')); ?></p>
            <form method="post" action="">
                <?php wp_nonce_field('caspian_create_backup_action', 'caspian_create_backup_nonce'); ?>
                <button type="submit" name="caspian_create_backup" class="button button-primary button-large"><?php echo esc_html(caspian_t('btn_manual')); ?></button>
            </form>
        </div>

        <h2><span class="dashicons dashicons-database"></span> <?php echo esc_html(caspian_t('list_title')); ?></h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th width="35%"><?php echo esc_html(caspian_t('col_filename')); ?></th>
                    <th width="10%"><?php echo esc_html(caspian_t('col_size')); ?></th>
                    <th width="20%"><?php echo esc_html(caspian_t('col_date')); ?></th>
                    <th width="35%"><?php echo esc_html(caspian_t('col_action')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($backups)) : ?>
                    <tr><td colspan="4" style="text-align:center;"><?php echo esc_html(caspian_t('no_backups')); ?></td></tr>
                <?php else : ?>
                    <?php foreach ($backups as $file) : 
                        $filename = basename($file);
                        $download_url = wp_nonce_url(admin_url('admin.php?page=caspian-backup&caspian_download=' . urlencode($filename)), 'caspian_download_' . $filename);
                    ?>
                        <tr id="row-<?php echo esc_attr(md5($filename)); ?>">
                            <td><?php echo esc_html($filename); ?></td>
                            <td><?php echo esc_html(round(filesize($file) / 1048576, 2) . ' MB'); ?></td>
                            <td><?php echo esc_html(date('Y-m-d H:i:s', filemtime($file))); ?></td>
                            <td>
                                <a href="<?php echo esc_url($download_url); ?>" class="button button-secondary"><span class="dashicons dashicons-download"></span> <?php echo esc_html(caspian_t('btn_download')); ?></a>
                                <button class="button button-link-delete caspian-del-btn" data-filename="<?php echo esc_attr($filename); ?>"><span class="dashicons dashicons-trash"></span> <?php echo esc_html(caspian_t('btn_delete')); ?></button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        
        <div style="text-align: center; margin-top: 30px; color: #888; font-size: 12px;">
            <?php echo wp_kses(caspian_t('developer'), ['a' => ['href' => [], 'target' => [], 'style' => []]]); ?>
        </div>
    </div>
    <?php
}