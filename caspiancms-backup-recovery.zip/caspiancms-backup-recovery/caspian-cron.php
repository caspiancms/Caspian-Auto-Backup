<?php
if (!defined('ABSPATH')) {
    $wp_load_path = realpath(__DIR__ . '/../../../wp-load.php');
    if (!$wp_load_path || !file_exists($wp_load_path)) {
        die('WordPress root not found.');
    }
    require_once $wp_load_path;
}

if (!defined('ABSPATH')) exit;

 $cron_token = md5(AUTH_KEY . 'caspian_cron_salt');
if (!isset($_GET['token']) || !hash_equals($cron_token, sanitize_text_field($_GET['token']))) {
    die('Access Denied!');
}

@set_time_limit(0);
require_once plugin_dir_path(__FILE__) . 'includes/class-caspian-backup-engine.php';
 $engine = new Caspian_Backup_Engine();

 $result = $engine->createBackup(home_url());

if (is_wp_error($result)) {
    echo "Backup Failed: " . esc_html($result->get_error_message());
} else {
    echo "Caspian WP Backup Created Successfully: " . esc_html($result);
}