=== CaspianCMS Backup & Recovery ===
Contributors: saeed_same, caspiancms
Tags: backup, restore, recovery, security, disaster recovery
Requires at least: 5.0
Tested up to: 7.1
Requires PHP: 7.2
Stable tag: 1.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Instantly recover your hacked WordPress site. Nuke & Pave restoration destroys infected files and rebuilds a clean site in seconds.

== Description ==

Caspian Backup & Recovery is a powerful disaster recovery tool for WordPress. Unlike standard backup plugins that only overwrite files (leaving hacker backdoors intact), this plugin uses a "Nuke and Pave" approach.

If your website gets hacked, you simply upload the latest backup package, run the `restore.php` file, and the system will completely destroy ALL current infected files and database tables, and rebuild your store from the clean backup in seconds.

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to the "Caspian Backup" menu in the admin sidebar.
4. Click "Create Manual Backup" or set up the Cron Job URL in your hosting panel.